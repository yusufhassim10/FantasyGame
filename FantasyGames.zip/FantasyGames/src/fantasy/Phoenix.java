package fantasy;

public class Phoenix extends Creature {
    private boolean hasRevived;

    public Phoenix(String name, int health, int attackPower) {
        super(name, health, attackPower);
        this.hasRevived = false;
    }

    @Override
    public void takeDamage(int amount) {
        health -= amount;
        if (health <= 0 && !hasRevived) {
            hasRevived = true;
            health = 50; // revive with 50 HP
            System.out.println(name + " has been defeated... but rises again from the ashes with 50 health!");
        } else if (health <= 0) {
            System.out.println(name + " has been permanently defeated!");
        } else {
            System.out.println(name + " takes " + amount + " damage. Remaining health: " + health);
        }
    }
}