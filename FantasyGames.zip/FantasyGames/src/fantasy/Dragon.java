package fantasy;

public class Dragon extends Creature {
    private int firePower;

    public Dragon(String name, int health, int attackPower, int firePower) {
        super(name, health, attackPower); // call Creature constructor
        this.firePower = firePower;
    }

    @Override
    public void attack(Creature target) {
        int totalDamage = attackPower + firePower;
        System.out.println(name + " breathes fire on " + target.name + " for " + totalDamage + " damage!");
        target.takeDamage(totalDamage);
    }

    public void roar() {
        System.out.println(name + " lets out a terrifying ROAR!");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Fire Power: " + firePower);
    }
}