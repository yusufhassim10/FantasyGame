package fantasy;

public class MainGame {
    public static void main(String[] args) {
        Dragon dragon = new Dragon("Smaug", 120, 20, 15);
        Phoenix phoenix = new Phoenix("Fawkes", 100, 18);

        System.out.println("=== Creature Details ===");
        dragon.displayInfo();
        phoenix.displayInfo();

        System.out.println("\n=== Battle Begins ===");
        dragon.roar();               // must exist in Dragon
        dragon.attack(phoenix);      // must exist in Dragon (overridden)
        phoenix.attack(dragon);      // must exist in Creature (inherited)
        dragon.attack(phoenix);
        phoenix.attack(dragon);
        dragon.attack(phoenix);      // test Phoenix revive
        phoenix.attack(dragon);

        System.out.println("\n=== Final Stats ===");
        dragon.displayInfo();
        phoenix.displayInfo();
    }
}