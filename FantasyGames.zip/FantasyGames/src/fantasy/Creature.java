package fantasy;

public class Creature {
    protected String name;
    protected int health;
    protected int attackPower;

    public Creature(String name, int health, int attackPower) {
        this.name = name;
        this.health = health;
        this.attackPower = attackPower;
    }

    // Attack another creature
    public void attack(Creature target) {
        System.out.println(name + " attacks " + target.name + " for " + attackPower + " damage!");
        target.takeDamage(attackPower);
    }

    // Take damage
    public void takeDamage(int amount) {
        health -= amount;
        System.out.println(name + " takes " + amount + " damage. Remaining health: " + health);
        if (health <= 0) {
            System.out.println(name + " has been defeated!");
        }
    }

    // Print info
    public void displayInfo() {
        System.out.println("Name: " + name + " | Health: " + health + " | Attack Power: " + attackPower);
    }
}